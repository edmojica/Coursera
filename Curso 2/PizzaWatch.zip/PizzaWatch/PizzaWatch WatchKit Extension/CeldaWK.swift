//
//  CeldaWK.swift
//  PizzaWatch
//
//  Created by Edson Mojica on 07/08/16.
//  Copyright © 2016 Edson Mojica. All rights reserved.
//

import WatchKit

class CeldaWK: NSObject {
    
    @IBOutlet var lblNombreIngrediente: WKInterfaceLabel!
    @IBOutlet var checkedImage: WKInterfaceImage!
    
    
    
    
}
