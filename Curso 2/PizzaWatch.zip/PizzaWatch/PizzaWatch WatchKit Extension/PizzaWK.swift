//
//  PizzaWK.swift
//  PizzaWatch
//
//  Created by Edson Mojica on 07/08/16.
//  Copyright © 2016 Edson Mojica. All rights reserved.
//

import Foundation


class PizzaWK {
    var tamano: String?
    var tipoMasa: String?
    var tipoQueso: String?
    var ingredientes: [String]?
    
    init ()
    {
        
    }
    
}